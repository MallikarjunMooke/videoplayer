// App.js
import React from 'react';
import VideoPage from './components/VideoPage';
import './App.css';

function App() {
  return (
    <div className="App">
      <VideoPage />
    </div>
  );
}

export default App;
